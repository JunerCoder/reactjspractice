<?php
header('Access-Control-Allow-Origin: *');

$server = 'localhost';
$username = 'root';
$password = '';
$dbname = 'kodego_db';

$con = mysqli_connect($server, $username, $password, $dbname);

$sql = "SELECT * FROM `users_tbl`";

mysqli_query($con, $sql);

$result = mysqli_query($con, $sql);


    echo '[';
    
    for($i = 0; $i < mysqli_num_rows($result); $i++){
        echo ($i > 0 ? ',' : '').json_encode(mysqli_fetch_object($result));
    }
    echo ']';


?>