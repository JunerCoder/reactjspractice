import React from 'react';

const Pagination = ({postPerPage, totalPost, setCurrentPage, currentPage}) => {
    let page = [];
    //100 / 10
    for(let i = 1; i <= totalPost/postPerPage; i++){
        page.push(i);
    }
    return (
        <>
        <div>
            {page.map((page_num, index) => {
                return(
                    <button key={index} className={page_num == currentPage ? 'btn btn-primary' : 'btn btn-outline-primary'} onClick={() => setCurrentPage(page_num)}>{page_num}</button>
                )
            })}
        </div>
        </>
    )
}

export default Pagination;