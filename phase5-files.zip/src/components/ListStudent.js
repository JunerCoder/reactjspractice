function ListStudent(){
    return(
        <>
        <div className="row">
            <div className="col-md-12 text-center">
                <h1>List Student</h1>
            </div>
        </div>
        </>
    )
}

export default ListStudent;