import React from 'react';
import Card from './Card';


const AllCards = ({currentPost}) => {
    return(
        <>
           {currentPost.map((item, index) => {
            return(
                <div key={index} className="d-inline-block">
                    <Card name={item.fname + " " + item.lname} age={item.age} img={item.image} />
                </div>
            )
           })}
        </>
    ) 
    
}

export default AllCards