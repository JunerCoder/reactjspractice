function Home() {
    return(
        <>
        <div className="row">
            <div className="col-md-12 text-center">
                <h1>Welcome to Homepage</h1>
            </div>
        </div>
        </>
    )
}

export default Home;