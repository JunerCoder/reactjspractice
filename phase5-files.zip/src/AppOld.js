import {useState, useEffect} from 'react';
import {BrowserRouter as Router, Route, Routes, withRouter, useFetcher} from 'react-router-dom';
import Home from './components/Home';
import Header from './Header';
import ListStudent from '../src/components/ListStudent';
import AddStudent from './components/AddStudent';
import EditStudent from './components/EditStudent';
import './App.css';
import axios from 'axios';

function AppOld() {

  const [fname, setFname] = useState();
  const [lname, setLname] = useState();
  const [age, setAge] = useState();
  const [arr, setArr] = useState([]);
  const url = "http://localhost/kodego/phase5/dbcon.php";

  const handleFormSubmit = (e) => {
    e.preventDefault();
    let getData = new FormData();
    getData.append('fname', fname);
    getData.append('lname', lname);
    getData.append('age', age);
    getData.append('function', 'insert');

    axios({
      method: 'POST',
      url: 'http://localhost/kodego/phase5/dbcon.php',
      data: getData,
      config: {header:'Content-Type: multipart/form-data'}
    }).then(function() {
      axios.get(url).then((response) => {
        setArr(response.data);
        setFname("");
        setLname("");
        setAge("");
      })
    })
  }

  const DelBtn = (e) =>{
    let getData = new FormData();
    getData.append('id', e.currentTarget.id)
    getData.append('function', 'delete');
    axios({
      method: 'POST',
      url: 'http://localhost/kodego/phase5/dbcon.php',
      data: getData,
    }).then(function() {
      axios.get(url).then((response) => {
        setArr(response.data);
        setFname("");
        setLname("");
        setAge("");
      })
    })
  }

  const UpBtn = (e) =>{
    // alert(e.currentTarget.id);
    let getData = new FormData();
    getData.append('function', 'update');
    getData.append('upid', e.currentTarget.title);
    getData.append('upfname', document.getElementById("upfname"+ e.currentTarget.title).value);
    getData.append('uplname', document.getElementById("uplname"+ e.currentTarget.title).value);
    getData.append('upage', document.getElementById("upage"+ e.currentTarget.title).value);

    axios({
      method: 'POST',
      url: 'http://localhost/kodego/phase5/dbcon.php',
      data: getData,
    }).then(function() {
      axios.get(url).then((response) => {
        setArr(response.data);
        // setFname("");
        // setLname("");
        // setAge("");
        alert("Data Updated Successfully!")
      })
    })
  }

  useEffect(() => {
    
    axios.get(url).then((response) => {
      // console.log(response.data);
      setArr(response.data);
    })

  },[]);


  return (
    <>
    {/* <main className='container'>
      <Router>
        <Header />
        <div>
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/list-student" element={<ListStudent />} />
            <Route path="/add-student" element={<AddStudent />} />
            <Route path="/edit-student" element={<EditStudent />} />
          </Routes>
        </div>
      </Router>
    </main> */}

   


    <div className='container'>
      <div className='col-md-12 mt-5'>
        <form method='POST'>
          First Name: <input type='text' name='fname' id='fname' value={fname} onChange={(e) => setFname(e.target.value)} className='form-control' /><br></br>
          Last Name: <input type='text' name='lname' id='lname' value={lname} onChange={(e) => setLname(e.target.value)} className='form-control' /><br></br>
          Age: <input type='text' name='age' id='age' value={age} onChange={(e) => setAge(e.target.value)} className='form-control' /><br></br>
          <button type='submit' className='btn btn-primary' onClick={handleFormSubmit}>submit</button>
        </form>
        <table className='table table-striped table-bordered mt-5'>
        <thead>
          <th>First Name:</th>
          <th>Last Name:</th>
          <th>Age:</th>
          <th>Action:</th>
        </thead>
        {arr.map((val) => {
          return(

            <tr key={val.id}>

          <td><input type='text' name='upfname' id={'upfname'+val.id} defaultValue={val.fname} onChange={(e) => e.target.value} className='form-control' /><br></br></td>
          <td><input type='text' name='uplname' id={'uplname'+val.id} defaultValue={val.lname} onChange={(e) => e.target.value} className='form-control' /><br></br></td>
          <td><input type='text' name='upage' id={'upage'+val.id} defaultValue={val.age} onChange={(e) => e.target.value} className='form-control' /><br></br></td>

              <button className='btn btn-danger mt-1' id={val.id} onClick={DelBtn}>Delete</button>
              <button className='btn btn-success mt-1' title={val.id} onClick={UpBtn}>Update</button>
            
            </tr>
          )})}
        
      </table>
      </div>
    </div>
    
    </>
  );  
}

export default AppOld;
