import React from "react";
import { useState, useEffect } from "react";
import axios from "axios";
import AllCards from './components/AllCards';
import Pagination from "./components/Pagination";

const App2 = () =>{

    const [arr, setArr] = useState([]);
    const url = "http://localhost/kodego/phase5/sample.php";

    const [currentPage, setCurrentPage] = useState(1);
    const [postPerPage, setPostPerPage] = useState(10);

    const lastPostIndex = currentPage * postPerPage; //up to item number 10
    const firstPostIndex = lastPostIndex - postPerPage; // 10-10 = 0

    const currentPost = arr.slice(firstPostIndex, lastPostIndex);

    // arr.slice(0, 9);

    useEffect(()=> {
        axios.get(url).then((response) =>{
            setArr(response.data);
        })}, []);

    return(
        <center>
            <h1>Contact List</h1>
            <AllCards currentPost = {currentPost} />
            <Pagination postPerPage = {postPerPage} totalPost = {arr.length} setCurrentPage={setCurrentPage} currentPage={currentPage} />
        </center>
    )
}

export default App2;