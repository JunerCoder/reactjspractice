<?php
header('Access-Control-Allow-Origin: *');

$server = 'localhost';
$username = 'root';
$password = '';
$dbname = 'kodego_db';

$con = mysqli_connect($server, $username, $password, $dbname);

$method = $_SERVER['REQUEST_METHOD'];

switch($method) {
    case 'GET':
        $sql = "SELECT * FROM `users_tbl`";
        break;
    case 'POST':
        $function = $_POST['function'];
        if($function == 'insert'){
            $fname = $_POST['fname'];
            $lname = $_POST['lname'];
            $age = $_POST['age'];

            $img = $_FILES['pic']['name'];
            $target_file = "public/images/".$_FILES["pic"]["name"];
            $file_url = "./images/".$_FILES["pic"]["name"];
            move_uploaded_file($_FILES["pic"]["tmp_name"], $target_file);


            $sql = "INSERT INTO `users_tbl`(`fname`, `lname`, `age`,`image`) VALUES ('$fname', '$lname', '$age','$file_url')";

        }else if($function == 'delete'){
            $id = $_POST['id'];

            $sql = "DELETE FROM `users_tbl` WHERE `id` = $id";
        }else if($function == 'update'){
            $id = $_POST['upid'];

            $upfname = $_POST['upfname'];
            $uplname = $_POST['uplname'];
            $upage = $_POST['upage'];

            $sql = "UPDATE `users_tbl` SET `fname`='$upfname', `lname`='$uplname', `age`='$upage' WHERE `id`=$id";

        }
        break;
}

$result = mysqli_query($con, $sql);

if($method == 'GET'){
    echo '[';
    
    for($i = 0; $i < mysqli_num_rows($result); $i++){
        echo ($i > 0 ? ',' : '').json_encode(mysqli_fetch_object($result));
    }
    echo ']';
}

?>